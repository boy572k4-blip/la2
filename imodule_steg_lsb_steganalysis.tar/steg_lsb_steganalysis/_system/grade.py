#!/usr/bin/env python3
"""
Grading script for steg_lsb_steganalysis lab.
Called by Labtainer instructor.py after extracting student artifacts.
Args: student_dir lab_name
"""
import os
import sys


def check_file_contains(student_dir, container, rel_path, keyword):
    """Check if file exists and contains keyword"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            try:
                content = open(path).read()
                return keyword.lower() in content.lower()
            except:
                pass
    return False


def check_file_exists(student_dir, container, rel_path):
    """Check if a file simply exists"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path = os.path.join(student_dir, container, rel_path)
    return any(os.path.isfile(p) for p in [full_path, alt_path])


def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    container = 'steg_lsb_steganalysis.analyst.student'
    results = {}

    # Step 1: lsb_distribution.txt contains 'suspect.wav'
    results['lsb_distribution'] = check_file_contains(
        student_dir, container,
        'steg_lab/lsb_distribution.txt', 'suspect.wav')

    # Step 2: histogram_lsb.png exists
    results['histogram_lsb'] = check_file_exists(
        student_dir, container,
        'steg_lab/histogram_lsb.png')

    # Step 3: chi_test_result.txt contains 'pvalue'
    results['chi_test'] = check_file_contains(
        student_dir, container,
        'steg_lab/chi_test_result.txt', 'pvalue')

    # Step 4: extracted_message.txt contains 'END'
    results['confirm_extract'] = check_file_contains(
        student_dir, container,
        'steg_lab/extracted_message.txt', 'END')

    # Step 5: steganalysis_report.txt contains 'CONCLUSION'
    results['steganalysis_report'] = check_file_contains(
        student_dir, container,
        'steg_lab/steganalysis_report.txt', 'CONCLUSION')

    labels = {
        'lsb_distribution':  'lsb_distribution',
        'histogram_lsb':     'histogram_lsb',
        'chi_test':          'chi_test',
        'confirm_extract':   'confirm_extract',
        'steganalysis_report': 'steganalysis_report',
    }

    for key, label in labels.items():
        mark = 'Y' if results[key] else 'N'
        print(f' {mark} -  {label}')


if __name__ == '__main__':
    main()
