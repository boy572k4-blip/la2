#!/usr/bin/env python3
"""
Grading script for steg_lsb_steganalysis lab.
Called by Labtainer instructor.py after extracting student artifacts.
Args: student_dir lab_name
"""
import os
import sys


def check_file_contains(student_dir, container, rel_path, keyword):
    """Check if file exists and contains keyword"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            try:
                content = open(path).read()
                return keyword.lower() in content.lower()
            except:
                pass
    return False


def check_file_exists(student_dir, container, rel_path):
    """Check if a file simply exists"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path = os.path.join(student_dir, container, rel_path)
    return any(os.path.isfile(p) for p in [full_path, alt_path])


def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    container = 'steg_lsb_steganalysis.analyst.student'
    results = {}

    results['lsb_distribution'] = check_file_contains(
        student_dir, container,
        'steg_lab/lsb_distribution.txt', 'LSB_DISTRIB_DONE')

    results['histogram_lsb'] = check_file_contains(
        student_dir, container,
        'steg_lab/histogram_info.txt', 'HIST_LSB_DONE')

    results['chi_test'] = check_file_contains(
        student_dir, container,
        'steg_lab/chi_test_result.txt', 'CHI_TEST_DONE')

    results['confirm_extract'] = check_file_contains(
        student_dir, container,
        'steg_lab/extracted_message.txt', 'EXTRACT_CONFIRM_DONE')

    results['steganalysis_report'] = check_file_contains(
        student_dir, container,
        'steg_lab/steganalysis_report.txt', 'STEG_REPORT_DONE')

    labels = {
        'lsb_distribution':  'lsb_distribution',
        'histogram_lsb':     'histogram_lsb',
        'chi_test':          'chi_test',
        'confirm_extract':   'confirm_extract',
        'steganalysis_report': 'steganalysis_report',
    }

    for key, label in labels.items():
        mark = 'Y' if results[key] else 'N'
        print(f' {mark} -  {label}')


if __name__ == '__main__':
    main()
