#!/bin/bash
service ssh start 2>/dev/null

mkdir -p /var/labtainer
echo "steg_lsb_steganalysis_seed" > /var/labtainer/seed

mkdir -p /home/ubuntu/.local
echo "steg_lsb_steganalysis_seed" > /home/ubuntu/.local/.seed
echo "student@labtainer.local"    > /home/ubuntu/.local/.email
echo "steg_lsb_steganalysis"      > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

touch /var/labtainer/did_param

mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

# Generate WAV files on first start
if [ ! -f /home/ubuntu/steg_lab/clean.wav ]; then
    python3 /home/ubuntu/steg_lab/generate_wav.py 2>/dev/null
    chown ubuntu:ubuntu /home/ubuntu/steg_lab/*.wav 2>/dev/null
fi

tail -f /dev/null
