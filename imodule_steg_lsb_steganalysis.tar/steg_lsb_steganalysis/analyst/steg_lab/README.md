# Steg LSB Steganalysis Lab

## Mục tiêu
Phân tích file âm thanh để phát hiện tin ẩn được giấu bằng phương pháp LSB.

## Các bước thực hành

### Bước 1: Tạo file WAV mẫu (đã có sẵn trong lab)
```bash
python3 steg_lab/generate_wav.py
```

### Bước 2: Phân tích phân phối bit LSB
```bash
python3 steg_lab/analyze_lsb.py
# Kết quả lưu vào: steg_lab/lsb_distribution.txt
```

### Bước 3: Vẽ histogram LSB
```bash
python3 steg_lab/plot_histogram.py
# Kết quả lưu vào: steg_lab/histogram_lsb.png
```

### Bước 4: Kiểm định Chi-Square
```bash
python3 steg_lab/chi_square_test.py
# Kết quả lưu vào: steg_lab/chi_test_result.txt
```

### Bước 5: Trích xuất thử nghiệm
```bash
python3 steg_lab/confirm_extract.py
# Kết quả lưu vào: steg_lab/extracted_message.txt
```

### Bước 6: Viết báo cáo tổng hợp
```bash
python3 steg_lab/steganalysis_report.py
# Kết quả lưu vào: steg_lab/steganalysis_report.txt
```

## Checkwork items
| Item | File cần tạo | Từ khóa cần có |
|------|-------------|----------------|
| lsb_distribution | steg_lab/lsb_distribution.txt | suspect.wav |
| histogram_lsb | steg_lab/histogram_lsb.png | (file phải tồn tại) |
| chi_test | steg_lab/chi_test_result.txt | pvalue |
| confirm_extract | steg_lab/extracted_message.txt | END |
| steganalysis_report | steg_lab/steganalysis_report.txt | CONCLUSION |
