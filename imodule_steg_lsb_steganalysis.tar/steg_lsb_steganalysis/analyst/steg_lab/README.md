# Steg LSB Steganalysis Lab

Lab starts in this directory:

```bash
/home/ubuntu/steg_lab
```

Run the scripts in order:

```bash
python3 generate_wav.py
python3 analyze_lsb.py
python3 plot_histogram.py
python3 chi_square_test.py
python3 confirm_extract.py
python3 steganalysis_report.py
nano analysis_answer.txt
```

Checkwork expects:

| Item | Script | Output file | Marker |
|---|---|---|---|
| lsb_distrib | analyze_lsb.py | lsb_distribution.txt | LSB_DISTRIB_DONE |
| hist_lsb | plot_histogram.py | histogram_info.txt | HIST_LSB_DONE |
| chi_test | chi_square_test.py | chi_test_result.txt | CHI_TEST_DONE |
| confirm_extract | confirm_extract.py | extracted_message.txt | EXTRACT_CONFIRM_DONE |
| steg_report | steganalysis_report.py | steganalysis_report.txt | STEG_REPORT_DONE |
| student_answer | analysis_answer.txt | analysis_answer.txt | suspect_is_stego=YES |
