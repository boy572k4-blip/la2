#!/usr/bin/env python3
"""
Bước 2 - Phân tích phân phối bit LSB của clean.wav và suspect.wav
Kết quả lưu vào steg_lab/lsb_distribution.txt
"""
import wave
import struct
import collections
import os

STEG_DIR = '/home/ubuntu/steg_lab'


def lsb_distribution(wav_path, lsb_bits=1):
    with wave.open(wav_path, 'r') as f:
        frames  = f.readframes(f.getnframes())
        n_ch    = f.getnchannels()
        sampw   = f.getsampwidth()

    fmt = f'<{len(frames) // 2}h'
    samples = struct.unpack(fmt, frames)

    lsb_vals = [s & ((1 << lsb_bits) - 1) for s in samples]
    counter  = collections.Counter(lsb_vals)
    total    = len(lsb_vals)

    lines = []
    lines.append(f'[{os.path.basename(wav_path)}] Phan phoi {lsb_bits}-bit LSB:')
    lines.append(f'  Total samples: {total}')
    for k in sorted(counter):
        pct = counter[k] / total * 100
        lines.append(f'  Gia tri {k:0{lsb_bits}b} ({k}): {counter[k]} mau = {pct:.2f}%')

    if lsb_bits == 1:
        ratio = counter[0] / max(counter[1], 1)
        lines.append(f'  Ratio 0/1 = {ratio:.4f}')
        if abs(ratio - 1.0) < 0.05:
            lines.append('  => Phan phoi GAN 50/50 -> Nghi ngo co giau tin LSB!')
        else:
            lines.append('  => Phan phoi KHONG deu -> Am thanh tu nhien.')

    return '\n'.join(lines)


def main():
    clean_path   = os.path.join(STEG_DIR, 'clean.wav')
    suspect_path = os.path.join(STEG_DIR, 'suspect.wav')
    out_path     = os.path.join(STEG_DIR, 'lsb_distribution.txt')

    if not os.path.isfile(clean_path) or not os.path.isfile(suspect_path):
        print('[ERROR] Khong tim thay clean.wav hoac suspect.wav trong', STEG_DIR)
        print('  Hay chay: python3 steg_lab/generate_wav.py')
        return 1

    result_clean   = lsb_distribution(clean_path)
    result_suspect = lsb_distribution(suspect_path)

    output = '\n'.join([
        '=' * 55,
        '  PHAN TICH PHAN PHOI LSB',
        '=' * 55,
        result_clean,
        '',
        result_suspect,
        '=' * 55,
    ])

    print(output)

    with open(out_path, 'w') as f:
        f.write(output + '\n')
    print(f'\n[OK] Da luu ket qua: {out_path}')
    return 0


if __name__ == '__main__':
    import sys
    sys.exit(main())
