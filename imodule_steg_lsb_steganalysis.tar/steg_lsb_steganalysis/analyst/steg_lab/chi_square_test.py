#!/usr/bin/env python3
"""
Bước 4 - Kiem dinh Chi-Square de ket luan thong ke ve file suspect.wav
Luu ket qua vao steg_lab/chi_test_result.txt
"""
import wave
import struct
import os
import sys

STEG_DIR = '/home/ubuntu/steg_lab'


def chi_test(wav_path):
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())
    samples = struct.unpack(f'<{len(frames) // 2}h', frames)

    n0 = sum(1 for s in samples if (s & 1) == 0)
    n1 = sum(1 for s in samples if (s & 1) == 1)
    expected = (n0 + n1) / 2.0

    # Chi-square statistic
    chi2 = ((n0 - expected) ** 2 + (n1 - expected) ** 2) / expected

    # p-value using scipy if available, else approximation
    try:
        from scipy.stats import chisquare
        stat, p = chisquare([n0, n1], [expected, expected])
    except ImportError:
        import math
        stat = chi2
        # Approximation for df=1
        p = math.exp(-chi2 / 2)

    name = os.path.basename(wav_path)
    lines = []
    lines.append(f'[{name}]')
    lines.append(f'  LSB=0 count : {n0}')
    lines.append(f'  LSB=1 count : {n1}')
    lines.append(f'  Expected    : {expected:.2f}')
    lines.append(f'  Chi2 stat   : {stat:.4f}')
    lines.append(f'  pvalue      : {p:.8f}')
    if p < 0.05:
        lines.append('  => p < 0.05 : Phan phoi KHONG deu -> Am thanh TU NHIEN (khong co tin an)')
    else:
        lines.append('  => p >= 0.05: Phan phoi GAN DIEU -> NGHI NGO giau tin LSB!')
    return '\n'.join(lines)


def main():
    clean_path   = os.path.join(STEG_DIR, 'clean.wav')
    suspect_path = os.path.join(STEG_DIR, 'suspect.wav')
    out_path     = os.path.join(STEG_DIR, 'chi_test_result.txt')

    if not os.path.isfile(clean_path) or not os.path.isfile(suspect_path):
        print('[ERROR] Khong tim thay clean.wav hoac suspect.wav trong', STEG_DIR)
        return 1

    result_clean   = chi_test(clean_path)
    result_suspect = chi_test(suspect_path)

    output = '\n'.join([
        '=' * 55,
        '  CHI-SQUARE TEST - STEGANALYSIS',
        '=' * 55,
        result_clean,
        '',
        result_suspect,
        '=' * 55,
    ])

    print(output)

    with open(out_path, 'w') as f:
        f.write(output + '\n')
    print(f'\n[OK] Da luu ket qua: {out_path}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
