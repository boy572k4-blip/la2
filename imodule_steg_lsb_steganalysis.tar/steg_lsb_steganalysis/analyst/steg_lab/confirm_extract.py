#!/usr/bin/env python3
"""
Bước 5 - Trich xuat thu nghiem thong diep an tu suspect.wav
Luu ket qua vao steg_lab/extracted_message.txt
"""
import wave
import struct
import os
import sys

STEG_DIR = '/home/ubuntu/steg_lab'
DELIMITER = '||END||'
MAX_BITS  = 8000 * 8   # toi da 8000 ky tu


def extract_lsb(wav_path, max_bits=MAX_BITS):
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())
    samples = struct.unpack(f'<{len(frames) // 2}h', frames)

    bits = [str(s & 1) for s in samples[:max_bits]]
    bit_str = ''.join(bits)

    msg = ''
    i   = 0
    while i + 8 <= len(bit_str):
        byte  = bit_str[i:i + 8]
        value = int(byte, 2)
        if value == 0:
            break
        msg += chr(value)
        if msg.endswith(DELIMITER):
            return msg[:-len(DELIMITER)], True
        i += 8

    return msg, False


def main():
    suspect_path = os.path.join(STEG_DIR, 'suspect.wav')
    out_path     = os.path.join(STEG_DIR, 'extracted_message.txt')

    if not os.path.isfile(suspect_path):
        print('[ERROR] Khong tim thay suspect.wav trong', STEG_DIR)
        return 1

    print('=' * 55)
    print('  TRICH XUAT THONG DIEP AN - CONFIRM EXTRACT')
    print('=' * 55)
    print(f'[INFO] Dang trich xuat tu: {suspect_path}')

    message, found = extract_lsb(suspect_path)

    lines = []
    if found:
        lines.append(f'[OK] Tim thay delimiter "{DELIMITER}"')
        lines.append(f'[OK] Thong diep an: "{message}"')
        lines.append(f'[CONFIRM] Xac nhan: suspect.wav CO chua tin an!')
        lines.append(f'END: extraction successful')
        lines.append('EXTRACT_CONFIRM_DONE')
    else:
        lines.append('[WARNING] Khong tim thay delimiter')
        lines.append(f'[RAW] Noi dung trich xuat (100 ky tu dau): "{message[:100]}"')
        lines.append('[NOTE] File co the khong chua tin an, hoac su dung delimiter khac')
        lines.append(f'END: extraction attempted')

    output = '\n'.join(lines)
    print(output)
    print('=' * 55)

    with open(out_path, 'w') as f:
        f.write(output + '\n')
    print(f'\n[OK] Da luu ket qua: {out_path}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
