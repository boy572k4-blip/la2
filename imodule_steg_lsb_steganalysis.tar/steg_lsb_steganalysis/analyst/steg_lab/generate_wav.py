#!/usr/bin/env python3
"""
Tạo 2 file WAV cho bài lab steganalysis:
  clean.wav   - file âm thanh bình thường (không giấu tin)
  suspect.wav - file đã được giấu thông điệp bằng LSB
"""
import wave
import struct
import math
import random
import os

STEG_DIR = '/home/ubuntu/steg_lab'
SECRET_MSG = 'Day la thong diep bi mat duoc giau bang LSB||END||'
SAMPLE_RATE = 44100
DURATION    = 3      # giây
NUM_SAMPLES = SAMPLE_RATE * DURATION


def gen_natural_samples(n, seed=42):
    """Tạo mẫu âm thanh tự nhiên (dạng sine có noise)"""
    rng = random.Random(seed)
    samples = []
    for i in range(n):
        val = int(8000 * math.sin(2 * math.pi * 440 * i / SAMPLE_RATE)
                  + 2000 * math.sin(2 * math.pi * 880 * i / SAMPLE_RATE)
                  + rng.randint(-500, 500))
        val = max(-32768, min(32767, val))
        samples.append(val)
    return samples


def write_wav(path, samples, rate=SAMPLE_RATE):
    with wave.open(path, 'w') as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(rate)
        f.writeframes(struct.pack(f'<{len(samples)}h', *samples))


def msg_to_bits(msg):
    bits = []
    for ch in msg:
        b = ord(ch)
        for i in range(7, -1, -1):
            bits.append((b >> i) & 1)
    return bits


def embed_lsb(samples, msg):
    bits = msg_to_bits(msg)
    out  = list(samples)
    for idx, bit in enumerate(bits):
        if idx >= len(out):
            break
        out[idx] = (out[idx] & ~1) | bit
    return out


os.makedirs(STEG_DIR, exist_ok=True)

samples = gen_natural_samples(NUM_SAMPLES)

clean_path   = os.path.join(STEG_DIR, 'clean.wav')
suspect_path = os.path.join(STEG_DIR, 'suspect.wav')

write_wav(clean_path, samples)
print(f'[OK] clean.wav  -> {clean_path}')

stego_samples = embed_lsb(samples, SECRET_MSG)
write_wav(suspect_path, stego_samples)
print(f'[OK] suspect.wav -> {suspect_path}')
print(f'[INFO] Secret message: "{SECRET_MSG}"')
