#!/usr/bin/env python3
"""
Generate two WAV files for the steganalysis lab:
  clean.wav   - normal audio with a biased LSB distribution
  suspect.wav - audio with LSB payload-like data and a hidden message
"""
import math
import os
import random
import struct
import wave

STEG_DIR = "/home/ubuntu/steg_lab"
SECRET_MSG = "Day la thong diep bi mat duoc giau bang LSB||END||"
SAMPLE_RATE = 44100
DURATION = 3
NUM_SAMPLES = SAMPLE_RATE * DURATION


def gen_natural_samples(n, seed=42):
    """Create natural-looking audio samples with deliberately biased LSBs."""
    rng = random.Random(seed)
    samples = []
    for i in range(n):
        val = int(
            8000 * math.sin(2 * math.pi * 440 * i / SAMPLE_RATE)
            + 2000 * math.sin(2 * math.pi * 880 * i / SAMPLE_RATE)
            + rng.randint(-500, 500)
        )
        val = max(-32768, min(32767, val))

        # Bias clean.wav so LSB=0 appears more often than LSB=1.
        # This gives students a clear natural baseline.
        if rng.random() < 0.72:
            val = val & ~1
        else:
            val = (val & ~1) | 1
        samples.append(val)
    return samples


def write_wav(path, samples, rate=SAMPLE_RATE):
    with wave.open(path, "w") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(rate)
        f.writeframes(struct.pack(f"<{len(samples)}h", *samples))


def msg_to_bits(msg):
    bits = []
    for ch in msg:
        b = ord(ch)
        for i in range(7, -1, -1):
            bits.append((b >> i) & 1)
    return bits


def embed_lsb(samples, msg, seed=2026):
    bits = msg_to_bits(msg)
    out = list(samples)
    for idx, bit in enumerate(bits):
        if idx >= len(out):
            break
        out[idx] = (out[idx] & ~1) | bit

    # Fill the remaining LSB stream with payload-like random bits.
    # The hidden message remains at the start, so confirm_extract.py works.
    rng = random.Random(seed)
    for idx in range(len(bits), len(out)):
        out[idx] = (out[idx] & ~1) | rng.randint(0, 1)
    return out


def main():
    os.makedirs(STEG_DIR, exist_ok=True)

    samples = gen_natural_samples(NUM_SAMPLES)

    clean_path = os.path.join(STEG_DIR, "clean.wav")
    suspect_path = os.path.join(STEG_DIR, "suspect.wav")

    write_wav(clean_path, samples)
    print(f"[OK] clean.wav -> {clean_path}")

    stego_samples = embed_lsb(samples, SECRET_MSG)
    write_wav(suspect_path, stego_samples)
    print(f"[OK] suspect.wav -> {suspect_path}")
    print(f'[INFO] Secret message: "{SECRET_MSG}"')


if __name__ == "__main__":
    main()
