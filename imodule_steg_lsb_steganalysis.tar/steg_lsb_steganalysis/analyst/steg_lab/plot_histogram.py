#!/usr/bin/env python3
"""
Bước 3 - Vẽ histogram LSB cho clean.wav và suspect.wav
Lưu ảnh vào steg_lab/histogram_lsb.png
"""
import wave
import struct
import os
import sys

STEG_DIR = '/home/ubuntu/steg_lab'


def get_lsb(wav_path):
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())
    samples = struct.unpack(f'<{len(frames) // 2}h', frames)
    return [s & 1 for s in samples]


def main():
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print('[ERROR] matplotlib khong duoc cai dat. Chay: pip3 install matplotlib')
        return 1

    clean_path   = os.path.join(STEG_DIR, 'clean.wav')
    suspect_path = os.path.join(STEG_DIR, 'suspect.wav')
    out_path     = os.path.join(STEG_DIR, 'histogram_lsb.png')

    if not os.path.isfile(clean_path) or not os.path.isfile(suspect_path):
        print('[ERROR] Khong tim thay clean.wav hoac suspect.wav trong', STEG_DIR)
        return 1

    lsbs_clean   = get_lsb(clean_path)
    lsbs_suspect = get_lsb(suspect_path)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    for ax, lsbs, path, title, color_pair in zip(
            axes,
            [lsbs_clean, lsbs_suspect],
            [clean_path, suspect_path],
            ['File goc (clean.wav)', 'File nghi ngo (suspect.wav)'],
            [('steelblue', 'cornflowerblue'), ('tomato', 'salmon')]):

        total  = len(lsbs)
        ratio0 = lsbs.count(0) / total
        ratio1 = lsbs.count(1) / total

        bars = ax.bar([0, 1], [ratio0, ratio1],
                      color=color_pair,
                      edgecolor='black',
                      linewidth=0.8,
                      width=0.5)

        ax.set_title(title, fontsize=14, fontweight='bold', pad=12)
        ax.set_xticks([0, 1])
        ax.set_xticklabels(['LSB = 0', 'LSB = 1'], fontsize=11)
        ax.set_xlabel('Gia tri LSB', fontsize=11)
        ax.set_ylabel('Ti le', fontsize=11)
        ax.set_ylim(0, 0.7)
        ax.axhline(y=0.5, color='green', linestyle='--', linewidth=1.2,
                   label='Nguong 50%')
        ax.legend(fontsize=9)
        ax.grid(axis='y', alpha=0.3)

        for bar, val in zip(bars, [ratio0, ratio1]):
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.01,
                    f'{val:.4f}', ha='center', va='bottom', fontsize=10)

    fig.suptitle('Histogram Phan Phoi Bit LSB - Steganalysis', fontsize=15, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    plt.close()

    print(f'[OK] Da luu histogram: {out_path}')
    print('[INFO] Mo file de xem: xdg-open steg_lab/histogram_lsb.png')
    return 0


if __name__ == '__main__':
    sys.exit(main())
