#!/usr/bin/env python3
"""
Bước 5 (bổ sung) - Tong hop bao cao steganalysis
Doc ket qua cac buoc truoc va tao bao cao tong the
Luu vao steg_lab/steganalysis_report.txt
"""
import os
import sys
import datetime

STEG_DIR = '/home/ubuntu/steg_lab'


def read_file_safe(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except Exception:
        return '[Chua co du lieu - hay chay script tuong ung truoc]'


def main():
    lsb_dist_path  = os.path.join(STEG_DIR, 'lsb_distribution.txt')
    chi_path       = os.path.join(STEG_DIR, 'chi_test_result.txt')
    extract_path   = os.path.join(STEG_DIR, 'extracted_message.txt')
    histogram_path = os.path.join(STEG_DIR, 'histogram_lsb.png')
    out_path       = os.path.join(STEG_DIR, 'steganalysis_report.txt')

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    histogram_status = 'CO (histogram_lsb.png)' if os.path.isfile(histogram_path) \
        else 'CHUA CO - chay plot_histogram.py'

    lsb_content  = read_file_safe(lsb_dist_path)
    chi_content  = read_file_safe(chi_path)
    ext_content  = read_file_safe(extract_path)

    # Simple auto-conclusion based on chi_test output
    if 'NGHI NGO' in chi_content or 'p >= 0.05' in chi_content:
        verdict = 'suspect.wav CO CHUA TIN AN (LSB steganography duoc xac nhan)'
        action  = 'Bao cao cho co quan chuc nang de dieu tra them'
    else:
        verdict = 'Khong co du bang chung ro rang ve tin an'
        action  = 'Tiep tuc theo doi va phan tich sau'

    report = f"""================================================================
  BAO CAO STEGANALYSIS - LAB: steg_lsb_steganalysis
================================================================
Thoi gian phan tich : {now}
Doi tuong phan tich : clean.wav, suspect.wav
Phuong phap         : LSB Distribution Analysis + Chi-Square Test

----------------------------------------------------------------
PHAN 1: PHAN PHOI BIT LSB
----------------------------------------------------------------
{lsb_content}

----------------------------------------------------------------
PHAN 2: KIEM DINH CHI-SQUARE
----------------------------------------------------------------
{chi_content}

----------------------------------------------------------------
PHAN 3: TRICH XUAT THU NGHIEM
----------------------------------------------------------------
{ext_content}

----------------------------------------------------------------
PHAN 4: HISTOGRAM
----------------------------------------------------------------
Trang thai : {histogram_status}

----------------------------------------------------------------
CONCLUSION (KET LUAN)
----------------------------------------------------------------
Ket qua   : {verdict}
Hanh dong : {action}

Ghi chu:
  - File co phan phoi LSB gan 50/50 la dau hieu cua LSB steganography
  - Chi-square p >= 0.05 cho thay phan phoi qua dieu -> bat thuong
  - Viec trich xuat thanh cong thong diep la bang chung xac nhan
================================================================
"""

    print(report)

    with open(out_path, 'w') as f:
        f.write(report)
    print(f'[OK] Da luu bao cao: {out_path}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
